#include<stdio.h>
#include "ohos_init.h" // open Harmony Operation System init header file
#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"
#include <unistd.h>
#include "wifiiot_i2c.h"
#include "stdint.h"
#include "wifiiot_i2c_ex.h"

#include "netif.h"
#include "netifapi.h"
#include "api_shell.h"
#include "wifi_device.h"


#define MOTER_ON 1
#define MOTER_OFF 0
#define BH1750_ADDR 0x23
#define SHT30_ADDR 0x44

static int g_ConnectSuccess = 0;
int wait_connect_result(void){
    int i = 0;
    for(i = 0; i < 4; i++){
        if(g_ConnectSuccess == 1){
            return 1;
        }
        usleep(1000000);
    }
    return 0;
}
void OnWifiConnectChangeHandler(int state, WifiLinkedInfo *info){
    printf("wifi的连接状态改变了\n");
    if(info == NULL){
        printf("wifi连接失败\n");
    }
    else{
        if(state == WIFI_STATE_AVALIABLE){
            g_ConnectSuccess = 1;
            printf("wifi连接成功\n");
        }else{
            g_ConnectSuccess = 0;
        }
    }
}
void wifi_config(void){
    WifiErrorCode result;
    printf("wifi 配置中...\n");
    WifiEvent g_wifiEventHandler = {0};
    g_wifiEventHandler.OnWifiConnectionChanged = OnWifiConnectChangeHandler;
    RegisterWifiEvent(&g_wifiEventHandler);
    result = EnableWifi();
    if(result != WIFI_SUCCESS){
        printf("wifi打开失败\n");
        return;
    }else{
        printf("wifi打开成功\n");
    }
    WifiErrorCode code = IsWifiActive();
    if(code != WIFI_STA_ACTIVE){
        printf("该设备不支持STA， 错误原因是:%d\n", code);
        return;
    }else{
        printf("该设备支持STA模式\r\n");
    }
    // 3. 配置wifi名称和密码
    int connect_result;
    WifiDeviceConfig config = {0};
    strcpy(config.ssid, "连你个大头鬼分身");
    strcpy(config.preSharedKey, "asdfghjkl");
    config.securityType = WIFI_SEC_TYPE_PSK; // 加密类型
    result = AddDeviceConfig(&config, &connect_result);
    if(result != WIFI_SUCCESS){
        printf("配置wifi失败，错误原因是%d\n", result);
        return;
    }else{
        printf("配置wifi成功\n");
    }

    // 4. 连接wifi
    result = ConnectTo(connect_result);
    usleep(3000000);
    if(result == WIFI_SUCCESS && wait_connect_result() == 1){
        printf("连接wifi成功\n");
    }else{
        printf("连接wifi失败, 原因是%d\n", result);
        return;
    }

    // 连接成功之后，可以通过dhcp获取ip地址
    // 获取操作ip的接口
    struct netif *lwip_netif = netifapi_netif_find("wlan0");
    // 开启dhcp
    if(lwip_netif){
        dhcp_start(lwip_netif);
    }else{
        printf("获取网络接口失败\n");
        return;
    }

    // 打印获取的ip地址
    while(1){
        if(dhcp_is_bound(lwip_netif) == ERR_OK){
            printf("<--DHCP State ok -->\r\n");
            // 打印获取的ip信息
            netifapi_netif_common(lwip_netif, dhcp_clients_info_show, NULL);
            break;
        }
        usleep(100000);
    }
}

static float Sh3x_CalcRH(unsigned short rawValue){
    //RH = rawValue / (2^16-1) * 100
    float humidity = 0;
    humidity = (float)rawValue / 65535 * 100;
    return humidity;
}
static float SH3x_CalcTemperature(unsigned short rawValue){
    //T = -45 + 175 * rawValue / (2^16-1)
    float temperature = 0;
    temperature = 175 * (float)rawValue / 65535 - 45;
    return temperature;
}
static unsigned char SHT3x_CheckCrc(unsigned char data[], unsigned char nbrOfBytes, unsigned char checksum){
    unsigned char crc = 0xFF;
    unsigned char bit = 0;
    unsigned char byteCtr = 0;
    //calculates 8-Bit checksum with given polynomial
    for(byteCtr = 0; byteCtr < nbrOfBytes; ++byteCtr){
        crc ^= (data[byteCtr]);
        for(bit = 8; bit > 0; --bit){
            if(crc & 0x80) crc = (crc << 1) ^ 0x131;
            else crc = (crc << 1);
        }
    }
    if(crc != checksum) return 1;
    else return 0;
}
// 温湿度传感器
void SHT30_Init(void){
    // 也是使用I2C接口来实现
    // 首先要初始化I2C接口
    WifiIotI2cData sht30_i2c_data = {0};
    unsigned char send_data[2] = {0x22, 0x36};
    sht30_i2c_data.sendBuf = send_data;
    sht30_i2c_data.sendLen = 2;
    I2cWrite(WIFI_IOT_I2C_IDX_1, (SHT30_ADDR<<1|0x00), &sht30_i2c_data);
}
void Moter_Init(void){
    GpioInit();
    IoSetFunc(WIFI_IOT_GPIO_IDX_8, WIFI_IOT_IO_FUNC_GPIO_8_GPIO);
    GpioSetDir(WIFI_IOT_GPIO_IDX_8, WIFI_IOT_GPIO_DIR_OUT);
}

void Moter_Set(int state){
    if(state == MOTER_ON){
        GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, WIFI_IOT_GPIO_VALUE1);
    }
    if(state == MOTER_OFF){
        GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, WIFI_IOT_GPIO_VALUE0);
    }
}
void key1_pressed(char *arg){
    (void)arg;
    printf("press key1\n");
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_VALUE1); // 灯亮
    Moter_Set(MOTER_ON);
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_14, WIFI_IOT_GPIO_VALUE1);
}

void key2_pressed(char * arg){
    (void)arg;
    printf("press key2\n");
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_VALUE0); // 灯灭
    Moter_Set(MOTER_OFF);
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_14, WIFI_IOT_GPIO_VALUE0);
}

void key_Init(void){
    GpioInit();
    IoSetFunc(WIFI_IOT_GPIO_IDX_11, WIFI_IOT_IO_FUNC_GPIO_11_GPIO);
    GpioSetDir(WIFI_IOT_GPIO_IDX_11, WIFI_IOT_GPIO_DIR_IN);
    // 按钮提起产生中断
    IoSetPull(WIFI_IOT_GPIO_IDX_11, WIFI_IOT_IO_PULL_UP);

    IoSetFunc(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_IO_FUNC_GPIO_12_GPIO);
    GpioSetDir(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_GPIO_DIR_IN);
    // 按钮提起产生中断
    IoSetPull(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_IO_PULL_UP);

    // 现在要告诉系统按键按下去后,要执行key1_pressed函数
    GpioRegisterIsrFunc(WIFI_IOT_GPIO_IDX_11, WIFI_IOT_INT_TYPE_EDGE, WIFI_IOT_GPIO_EDGE_FALL_LEVEL_LOW, key1_pressed, NULL);
    GpioRegisterIsrFunc(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_INT_TYPE_EDGE, WIFI_IOT_GPIO_EDGE_FALL_LEVEL_LOW, key2_pressed, NULL);
}
void BH1750_Init(void){
    // 需要通过SDA指令往芯片中发送固定的指令
    WifiIotI2cData bh1750_i2c_data = {0};
    unsigned char send_data[1] = {0x01};
    bh1750_i2c_data.sendBuf = send_data;
    bh1750_i2c_data.sendLen = 1;
    I2cWrite(WIFI_IOT_I2C_IDX_1, (BH1750_ADDR<<1|0x00), &bh1750_i2c_data);
}
void E53IA1_Init(void){
    // 紫外灯初始化，连接的是GPIO14
    GpioInit();
    IoSetFunc(WIFI_IOT_GPIO_IDX_14, WIFI_IOT_IO_FUNC_GPIO_14_GPIO);
    GpioSetDir(WIFI_IOT_GPIO_IDX_14, WIFI_IOT_GPIO_DIR_OUT);

    // BH1750管脚初始化
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_0, WIFI_IOT_IO_FUNC_GPIO_0_I2C1_SDA);
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_1, WIFI_IOT_IO_FUNC_GPIO_1_I2C1_SCL);

    //调用 鸿蒙内核提供的
    I2cInit(WIFI_IOT_GPIO_IDX_1, 400000);
    I2cSetBaudrate(WIFI_IOT_I2C_IDX_1, 400000);

    BH1750_Init(); // 光敏传感器初始化
    SHT30_Init(); // 温湿度传感器初始化
}
void BH1750_Start(void){
    WifiIotI2cData bh1750_i2c_data = {0};
    unsigned char send_data[1] = {0x10}; // 启动光敏检测指令
    bh1750_i2c_data.sendBuf = send_data;
    bh1750_i2c_data.sendLen = 1;
    I2cWrite(WIFI_IOT_I2C_IDX_1, (BH1750_ADDR<<1|0x00), &bh1750_i2c_data);
}
void HelloWorld(void) // define HelloWorld function
{
    float lux = 0;
    WifiIotI2cData bh1750_i2c_data = {0};
    unsigned char recv_data[2] = {0};

    WifiIotI2cData sht30_i2c_data = {0};
    unsigned char recv_data_sht30[6] = {0}; // 用来接收温湿度传感器的数据
    unsigned char send_data_sht30[2] = {0xE0, 0x00}; // 用来发送给温湿度传感器的数据
    unsigned char data[3];// 用于处理温湿度传感器的数据
    float temperature = 0, humidity = 0;
    printf("Open Harmony Hello World!\n"); // print "Hello World!" to the console
    GpioInit();
    key_Init(); // initialize key
    Moter_Init();  // initialize Moter
    E53IA1_Init(); // initialize E53IA1
    wifi_config(); // wifi configuration

    // 实现灯可以不断闪烁
    while (1) // loop
    {
        GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_VALUE1); // 灯亮
        usleep(2000000); // delay 2s
        GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_VALUE0); // 灯灭
        usleep(2000000); // delay 2s
    }
    IoSetFunc(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_IO_FUNC_GPIO_2_GPIO);
    GpioSetDir(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_DIR_OUT);
    E53IA1_Init();
    while(1){
        // BH1750 要想获取光照值，首先必须启动检测，然后再发送指令获取光照值
        BH1750_Start();
        usleep(18000);
        bh1750_i2c_data.receiveBuf = recv_data;
        bh1750_i2c_data.receiveLen = 2;
        I2cRead(WIFI_IOT_I2C_IDX_1, (BH1750_ADDR<<1|0x01), &bh1750_i2c_data);
        lux = (float)(((recv_data[0] << 8) + recv_data[1]) / 1.2); // 计算光照值
        printf("lux = %.2f\n", lux);
        if(lux < 50) // 光照值小于50时，开启紫外灯
        {
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_14, WIFI_IOT_GPIO_VALUE1);
        }
        else
        {
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_14, WIFI_IOT_GPIO_VALUE0);
        }

        sht30_i2c_data.sendBuf = send_data_sht30;
        sht30_i2c_data.sendLen = 2;
        sht30_i2c_data.receiveBuf = recv_data_sht30;
        sht30_i2c_data.receiveLen = 6;
        I2cWriteread(WIFI_IOT_I2C_IDX_1, (SHT30_ADDR<<1|0x00), &sht30_i2c_data);
        // 温湿度数据包含六个字节， 前两个字节是温度值，第三个字节是校验码
        data[0] = recv_data_sht30[0];
        data[1] = recv_data_sht30[1];
        data[2] = recv_data_sht30[2];
        // data数据里面存放的温度和验证码

        if(!SHT3x_CheckCrc(data, 2, data[2])){
            temperature = SH3x_CalcTemperature((unsigned short)(data[0] << 8) | data[1]);
            printf("temperature = %.2f\n", temperature);
        }

        data[0] = recv_data_sht30[3];
        data[1] = recv_data_sht30[4];
        data[2] = recv_data_sht30[5];

        if(!SHT3x_CheckCrc(data, 2, data[2])){
            humidity = Sh3x_CalcRH((unsigned short)(data[0] << 8) | data[1]);
            printf("humidity = %.2f\n", humidity);
        }

        usleep(1000000); //睡眠1s
    }
    return;
}

APP_FEATURE_INIT(HelloWorld); // initialize HelloWorld function

